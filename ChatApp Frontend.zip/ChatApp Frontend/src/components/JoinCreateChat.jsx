import { useState } from 'react'
import chatIcon from "../assets/chat_icon.png"
import toast from 'react-hot-toast';
import { createRoomByRoomService, joinChatApi } from '../services/RoomService';
import useChatContext from '../context/ChatContext';
import { useNavigate } from 'react-router';

const JoinCreateChat = () => {
  const[detail,setDetail]=useState({
    roomId:"",
    userName:"",
  });

  const {roomId,currentUser,connected,setRoomId,setCurrentUser,setConnected}=useChatContext();
  const navigate=useNavigate();

  function handleFormInputChange(event){
    setDetail({
      ...detail,
      [event.target.name]:event.target.value
    });
  }

  function validateForm(){
    if(detail.roomId===""||detail.userName===""){
      toast.error("Invalid Input !!!")
      return false;
    }
    return true;
  }

  async function joinChat(){
    if(validateForm()){
      try {
        const room=await joinChatApi(detail.roomId);
        toast.success("Joined")
        setCurrentUser(detail.userName);
        setRoomId(room.roomId); 
        setConnected(true);
        navigate("/chat");
      } catch (error) {
        if(error.status==404)
          toast.error(error.response.data);
        else
          toast.error("Error in Joining Room");
      }

    }
  }

  async function createRoom(){
    if(validateForm()){
      try {
        const response= await createRoomByRoomService(detail.roomId);
        console.log(response);
        toast.success("Room Created Successfully");
        setCurrentUser(detail.userName);
        setRoomId(response.roomId);
        setConnected(true);
        navigate('/chat');
      } catch (error) {
        console.log(error);
        if(error.status==400)
          toast.error("Room Already Exists")
        else
          toast("Error in Creating Room")
      }
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="border dark:border-gray-700 p-8 w-full flex flex-col gap-5 max-w-md rounded dark:bg-gray-900">

        <img src={chatIcon} alt="Chat App" className='w-24 mx-auto'/>

        <h1 className="text-2xl font-semibold text-center">Join Room / Create Room</h1>
        <div>
          <label htmlFor='' className='block font-medium mb-2'>Your Name</label><input onChange={handleFormInputChange} value={detail.userName} type='text' id="name" name='userName' placeholder='Enter Your Name' className="w-full dark:bg-gray-600 px-4 py-2 border dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
        </div>

        <div>
          <label className='block font-medium mb-2'>Room Id</label><input name='roomId' onChange={handleFormInputChange} value={detail.roomId} type='text' id="roomId" placeholder='Enter RoomId' className="w-full dark:bg-gray-600 px-4 py-2 border dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"/>
        </div>

        <div className='flex gap-44 mt-5'>
          <button onClick={createRoom} className="px-3 py-2 dark:bg-blue-600 hover:dark:bg-blue-800 rounded-full">Create Room</button>
          <button onClick={joinChat} className="px-3 py-2 dark:bg-green-600 hover:dark:bg-green-800 rounded-full">Join Room</button>
        </div>

      </div>
    </div>
  )
}

export default JoinCreateChat
