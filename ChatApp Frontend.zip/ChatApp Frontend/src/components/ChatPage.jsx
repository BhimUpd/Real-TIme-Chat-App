import { useEffect, useRef, useState } from 'react'
import { MdAttachFile, MdSend } from 'react-icons/md'
import Avatar from '../assets/avatar.png'
import { useNavigate } from 'react-router';
import useChatContext from '../context/ChatContext';
import SockJS from 'sockjs-client';
import { baseUrl } from '../config/AxiosHelper';
import { Stomp } from '@stomp/stompjs';
import toast from 'react-hot-toast';
import { getMessages } from '../services/RoomService';
import { timeAgo } from '../config/helper';

const ChatPage = () => {
  const {roomId,currentUser,connected,setRoomId,setCurrentUser,setConnected}=useChatContext();
  const navigate=useNavigate();
  useEffect(()=>{
    if(!connected)
      navigate("/");
  },[connected,roomId,currentUser])

  const [messages,setMessages]=useState([]);

  const [input,setInput]=useState("");
  const inputRef=useRef(null);
  const chatBoxRef=useRef(null);
  const [stompClient, setStompClient]=useState("");

  useEffect(()=>{
    async function loadMessages(){
      try {
        const messages=await getMessages(roomId);
        setMessages(messages);
      } catch (error) {
        
      }
    }
    if(connected)
      loadMessages();
  },[]);

  useEffect(()=>{
    if(chatBoxRef.current){
      chatBoxRef.current.scroll({
        top:chatBoxRef.current.scrollHeight,
        behavior:"smooth",
      })
    }
  },[messages]);

  useEffect(()=>{
    const connectWebSocket=()=>{
      const sock=new SockJS(`${baseUrl}/chat`);
      const client=Stomp.over(sock);
      client.connect({},()=>{
        setStompClient(client);
        toast.success("Connected");
        client.subscribe(`/topic/room/${roomId}`,(message)=>{
          console.log(message);
          const newMessage=JSON.parse(message.body);
          setMessages((prev)=>[...prev, newMessage]);
        });
      });
    };
    if (connected)
      connectWebSocket();
  },[roomId]);

  const sendMessage=async () => {
    if(stompClient && connected &&input.trim()){
      console.log(input);
      const message={
        sender:currentUser,
        content:input,
        roomId:roomId,
      };
      stompClient.send(
        `/app/sendMessage/${roomId}`,
        {},
        JSON.stringify(message)
      );
      setInput(""); 
    }
  };

  function handleLogOut(){
    stompClient.disconnect();
    setConnected(false);
    setRoomId("");
    setCurrentUser("");
    navigate("/");
    toast.success("Logged Out");

  }


  return (
    <div>

      <header className='border dark:border-gray-700 fixed w-full dark:bg-gray-900 flex justify-between p-5'>
        <div>
          <h1 className='text-xl font-semibold'>Room : <span>{roomId}</span></h1>
        </div>
        <div>
        <h1 className='text-xl font-semibold'>User : <span>{currentUser}</span></h1>
        </div>
        <div>
          <button onClick={handleLogOut} className="dark:bg-red-600 dark:hover:bg-red-900 px-3 py-2 rounded-full">Leave Room</button>
        </div>
      </header>

      <main ref={chatBoxRef} className='h-[calc(100vh-80px)] py-20 boder w-2/3 mx-auto dark:bg-neutral-900  overflow-auto  [&::-webkit-scrollbar]:w-2
  [&::-webkit-scrollbar-track]:rounded-full
  [&::-webkit-scrollbar-track]:bg-gray-500
  [&::-webkit-scrollbar-thumb]:rounded-full
  [&::-webkit-scrollbar-thumb]:bg-gray-500
  dark:[&::-webkit-scrollbar-track]:bg-neutral-800'>
        <div className='h-screen'>
          {
            messages.map((message,index)=>{
            const isCurrentUser = message.sender===currentUser;
            return (
            <div key={index} className={`text-white p-1 rounded-3xl pl-5 pr-2 w-fit m-2 ${isCurrentUser?"ml-auto bg-blue-900":"bg-gray-800"} `}>
            <div className={`flex justify-end space-x-2 ${isCurrentUser?"flex-row":"flex-row-reverse gap-2"}`}>
            <p className="font-bold text-sm">{message.sender}</p>
            <img src={Avatar} alt="." className="h-10 w-10 rounded-3xl" />
            </div>
            <div className='justify-end gap-4 mr-10'>
            <p>{message.content}</p>
            <p className='text-xs text-gray-300'>{timeAgo(message.timeStamp)}</p>
            </div>
            </div>
            )})
          }
        </div>
      </main>

      <div className='fixed bottom-2 w-full h-16'>
        <div className='p-1 border dark:border-gray-600 w-2/3 gap-2 items-center mx-auto flex justify-between dark:bg-gray-900 rounded-md'>
          <input  value={input} onChange={(e)=>{setInput(e.target.value)}} onKeyDown={(e)=>{if(e.key=='Enter'){sendMessage();}}} type='text' placeholder='Enter your message here...' className="dark:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-400 w-full px-2 py-2 rounded h-full"/>
          <button className='dark:bg-gray-700 px-3 py-3 rounded-full border dark:border-gray-900'><MdAttachFile/></button>
          <button onClick={sendMessage} className='dark:bg-green-600 px-3 py-3 rounded-full border dark:border-gray-900'><MdSend/></button>
        </div>
      </div>
    </div>
  )
}
export default ChatPage
